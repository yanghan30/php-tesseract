?package(php-tesseract):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="php-tesseract" command="/usr/bin/php-tesseract"

# Defaults for php-tesseract initscript
# sourced by /etc/init.d/php-tesseract
# installed at /etc/default/php-tesseract by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""

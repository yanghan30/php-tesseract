libphp-tesseract 0.1 php-tesseract (>> 0.1-0), php-tesseract (<< 0.1-99)
